<?php
 
//php
// Get raw data from request
$json = file_get_contents('php://input');

// Convert json to php object
$json_object = json_decode($json, true);

// Get pid value from json object

$username = $json_object['username']; //htmlspecialchars to be added
$password = $json_object['password']; //htmlspecialchars to be added
 
// array for JSON response
$response = array();
  
 
  // include db connect class
    require_once __DIR__ . '/db_connect.php';
 // connecting to db
    $myConnection= new DB_CONNECT();
    $myConnection->connect();
 
 // mysql inserting a new row
    $sqlCommand="select password from users where username= '$username'"; 
    
   // echo $sqlCommand;
    $result =mysqli_query($myConnection->myconn, "$sqlCommand");
    
    
       // check for empty result
        if (mysqli_num_rows($result) > 0) {
 
            $result = mysqli_fetch_array($result);
 
            if($password ==$result["password"]  )
            
            { $response["success"] = 1;
 
            $response["message"] = "Login Successful";
            }
            else {
      
            $response["success"] = 0;
            $response["message"] = "Login Failed";       
            }
            
        
            
            
        } else {
            // no product found
            $response["success"] = 0;
            $response["message"] = "Login Failed";
 
            // echo no users JSON
           
        }
        
        
            echo json_encode($response);
        
        
    
 
?>
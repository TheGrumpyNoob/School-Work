<?php
 
//php
// Get raw data from request
$json = file_get_contents('php://input');

// Convert json to php object
$json_object = json_decode($json, true);

// Get pid value from json object

$name = $json_object['name']; //htmlspecialchars to be added
$date = $json_object['date']; //htmlspecialchars to be added
 
// array for JSON response
$response = array();
  
 
  // include db connect class
    require_once __DIR__ . '/db_connect.php';
 // connecting to db
    $myConnection= new DB_CONNECT();
    $myConnection->connect();
 
 // mysql inserting a new row
    $sqlCommand="INSERT INTO events(name, date) VALUES('$name', '$date')";
    
   // echo $sqlCommand;
    $result =mysqli_query($myConnection->myconn, "$sqlCommand");

    // check if row inserted or not
    if ($result) {

      $response["message"] = "Event successfully Added.";
 
        // echoing JSON response
        echo json_encode($response);
    } else {
        // failed to insert row

        $response["message"] = "Oops! An error occurred.";
 
        // echoing JSON response
        echo json_encode($response);
    }
 
?>
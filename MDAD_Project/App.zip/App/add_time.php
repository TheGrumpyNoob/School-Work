<?php
 
//php
// Get raw data from request
$json = file_get_contents('php://input');

// Convert json to php object
$json_object = json_decode($json, true);

// Get pid value from json object

$name = $json_object['name']; //htmlspecialchars to be added
$time = $json_object['time']; //htmlspecialchars to be added
 
// array for JSON response
$response = array();
  
 
  // include db connect class
    require_once __DIR__ . '/db_connect.php';
 // connecting to db
    $myConnection= new DB_CONNECT();
    $myConnection->connect();
 
 // mysql inserting a new row
    $sqlCommand="INSERT INTO time(name, time) VALUES('$name', '$time')";
    
   // echo $sqlCommand;
    $result =mysqli_query($myConnection->myconn, "$sqlCommand");

    // check if row inserted or not
    if ($result) {
        // successfully inserted into database
        $response["success"] = 1;
      //  $response["message"] = "Product successfully created.   ".$sqlCommand;
      $response["message"] = "Product successfully created.";
 
        // echoing JSON response
        echo json_encode($response);
    } else {
        // failed to insert row
        $response["success"] = 0;
        $response["message"] = "Oops! An error occurred.";
 
        // echoing JSON response
        echo json_encode($response);
    }
 
?>
<?php
 
/*
 * Following code will list all the users
 */
 
   // include db connect class
    require_once __DIR__ . '/db_connect.php';
 // connecting to db
    $db= new DB_CONNECT();
    $db->connect();



    $sqlCommand="SELECT *FROM users";https://cp1.atspace.me/#
    $result =mysqli_query($db->myconn, "$sqlCommand");


// check for empty result
if (mysqli_num_rows($result) > 0) {
    // looping through all results
    // products node
    $response["users"] = array();
 
    while ($row = mysqli_fetch_array($result)) {
        // temporary array $product
        $users = array();
        $users["pid"] = $row["pid"];
        $users["username"] = $row["username"];
        $users["name"] = $row["name"];
        $users["age"] = $row["age"];
        $users["height"] = $row["height"];
        $users["weight"] = $row["weight"];
        
        // push single product into final response array
        array_push($response["users"], $users);

 
    }
    // success
    $response["success"] = 1;
 
 
    // echoing JSON response
  echo json_encode($response);
 
} else {
    // no products found
    $response["success"] = 0;
    $response["message"] = "No users found";
 
    // echo no users JSON
    echo json_encode($response);
}
?>
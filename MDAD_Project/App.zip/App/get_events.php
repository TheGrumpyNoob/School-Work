<?php
 
/*
 * Following code will list all the products
 */
 
   // include db connect class
    require_once __DIR__ . '/db_connect.php';
 // connecting to db
    $db= new DB_CONNECT();
    $db->connect();


// get all products from products table
    $sqlCommand="SELECT * FROM events";
    $result =mysqli_query($db->myconn, "$sqlCommand");


// check for empty result
if (mysqli_num_rows($result) > 0) {
    // looping through all results
    // products node
    $response["events"] = array();
 
    while ($row = mysqli_fetch_array($result)) {
        // temporary array $product
        $product = array();
        $product["name"] = $row["name"];
        $product["date"] = $row["date"];
        // push single product into final response array
        array_push($response["events"], $product);

 
    }
    // success
 
 
 
    // echoing JSON response
  echo json_encode($response);
 
} else {
    // no products found

    $response["message"] = "No event found";
 
    // echo no users JSON
    echo json_encode($response);
}
?>
<?php
 
//php
// Get raw data from request
$json = file_get_contents('php://input');

// Convert json to php object
$json_object = json_decode($json, true);

// Get pid value from json object

$username = $json_object['agegroup1']; //htmlspecialchars to be added
$password = $json_object['repetitions']; //htmlspecialchars to be added
 
// array for JSON response
$response = array();
  
 
  // include db connect class
    require_once __DIR__ . '/db_connect.php';
 // connecting to db
    $myConnection= new DB_CONNECT();
    $myConnection->connect();
 
 // mysql inserting a new row
    $sqlCommand="select * agegroup1 from pushup"; 
    
   // echo $sqlCommand;
    $result =mysqli_query($myConnection->myconn, "$sqlCommand");
    
    
       // check for empty result
     
        
        
            echo json_encode($response);
        
        
    
 
?>
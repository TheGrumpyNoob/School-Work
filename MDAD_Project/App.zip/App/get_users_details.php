<?php
  
/*/*
  * Following code will get single product details* Following code will g
 * A product is identified by product id (pid)
 */
 
  

// Get raw data from request
$json = file_get_contents('php://input');

// Convert json to php object
$json_object = json_decode($json, true);

// Get pid value from json object
$pid = $json_object['pid']; //htmlspecialchars to be added

 
// array for JSON response
$response = array();
 
 

// include db connect class
    require_once __DIR__ . '/db_connect.php';
 // connecting to db
    $db= new DB_CONNECT();
    $db->connect();


    // get a product from products table
    $sqlCommand="SELECT *FROM users WHERE pid = $pid";
    $result =mysqli_query($db->myconn, "$sqlCommand");

 
    if (!empty($result)) {
        // check for empty result
        if (mysqli_num_rows($result) > 0) {
 
            $result = mysqli_fetch_array($result);
 
            $users = array();
            $users["pid"] = $result["pid"];
            $users["username"] = $result["username"];
            $users["age"] = $result["age"];
            $users["weight"] = $result["weight"];
 
            // success
            $response["success"] = 1;
 
            // user node
            $response["users"] = array();
 
            array_push($response["users"], $users);
 
            // echoing JSON response
            echo json_encode($response);
        } else {
            $response["success"] = 0;
            $response["message"] = "No users found";
 

            // echo no product found JSON
            echo json_encode($response);
        }
    } else {
        // no product found
        $response["success"] = 0;
        $response["message"] = "No users found";
 
        // echo no users JSON
        echo json_encode($response);
    }
 
?>
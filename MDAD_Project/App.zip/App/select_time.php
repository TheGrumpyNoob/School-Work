<?php
 
/*
 * Following code will list all the products
 */
 
   // include db connect class
    require_once __DIR__ . '/db_connect.php';
 // connecting to db
    $db= new DB_CONNECT();
    $db->connect();


// get all products from products table
    $sqlCommand="SELECT id, name, time FROM time ORDER BY time ASC LIMIT 5";
    $result =mysqli_query($db->myconn, "$sqlCommand");


// check for empty result
if (mysqli_num_rows($result) > 0) {
    // looping through all results
    // products node
    $response["time"] = array();
 
    while ($row = mysqli_fetch_array($result)) {
        // temporary array $product
        $product = array();
        $product["id"] = $row ["id"];
        $product["name"] = $row["name"];
        $product["time"] = $row["time"];
        
        // push single product into final response array
        array_push($response["time"], $product);

 
    }
    // success
    $response["success"] = 1;
 
 
    // echoing JSON response
  echo json_encode($response);
 
} else {
    // no products found
    $response["success"] = 0;
    $response["message"] = "No products found";
 
    // echo no users JSON
    echo json_encode($response);
}
?>
<?php

//php
// Get raw data from request
$json = file_get_contents('php://input');

// Convert json to php object
$json_object = json_decode($json, true);

// Get pid value from json object
$pid = $json_object['pid'];
$username = $json_object['username']; //htmlspecialchars to be added
$age = $json_object['age']; //htmlspecialchars to be added
$weight = $json_object['weight']; 
 
// array for JSON response
$response = array();
 

// include db connect class
    require_once __DIR__ . '/db_connect.php';
 // connecting to db
    $db= new DB_CONNECT();
    $db->connect();

    // mysql update row with matched pid
    $sqlCommand="UPDATE users SET username = '$username', age = '$age', weight = '$weight' WHERE pid = $pid";
    $result =mysqli_query($db->myconn, "$sqlCommand");


    // check if row inserted or not
    if ($result) {
        // successfully updated
        $response["success"] = 1;
        $response["message"] = "User successfully updated.";
 
        // echoing JSON response
        echo json_encode($response);
    } else {
 
              // Wrong data types e.g. user enter 2d for price
              $response["success"] = 0;
              $response["message"] = "Error in updating. Data mismatched";
 
              // echoing JSON response
                echo json_encode($response);
             }
   

 
?>
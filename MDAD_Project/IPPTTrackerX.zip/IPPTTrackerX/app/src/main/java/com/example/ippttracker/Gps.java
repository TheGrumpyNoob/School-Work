package com.example.ippttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.icu.text.SimpleDateFormat;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.Calendar;
import java.util.Date;

public class Gps extends AppCompatActivity {
    SQLiteDatabase db;
    Button startbtn, stopbtn;
    TextView starttime,stoptime,timetaken;
    EditText nAme;
    int time1,time2;
    public static String ipBaseAddress = "http://yippt.atspace.cc/App";
    private static String url_create_product = Gps.ipBaseAddress+"/add_time.php";
    private static final String TAG_NAME = "name";
    private static final String TAG_TIME = "time";
    private static final String TAG_SUCCESS = "success";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gps);
        startbtn = (Button) findViewById(R.id.startbtn);
        stopbtn = (Button) findViewById(R.id.stopbtn);
        starttime = (TextView) findViewById(R.id.starttime);
        stoptime = (TextView) findViewById(R.id.stoptime);
        timetaken = (TextView) findViewById(R.id.timetaken);
        nAme = (EditText) findViewById(R.id.nAme);
        String sql= "create table if not exists IPPT(recId integer PRIMARY KEY autoincrement, Time text)";
        db = openOrCreateDatabase("IPPT.db", MODE_PRIVATE, null);
        db.execSQL(sql);

        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        startbtn.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            starttime.setText(dateFormat.format(new Date()));
                                            time1 = (int)((System.currentTimeMillis()/1000)%3600);
                                        }
                                    }
        );
        stopbtn.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View v) {
                                           stoptime.setText(dateFormat.format(new Date()));
                                           time2 = (int)((System.currentTimeMillis()/1000)%3600);
                                           if(time2>time1) {
                                               int difference = (3600 + time2 - time1) % 3600;
                                               timetaken.setText("You took " + difference + " Seconds to complete your run");

                                               String name = nAme.getText().toString();
                                               String sql = "insert into IPPT(Time) values ( '" + difference + "')";
                                               String result = updateTable(sql); //invoke the method to insert the record to DB

                                               if (name.isEmpty()) {
                                                   Toast.makeText(getApplicationContext(), "Please Fill in Name to be included into Leaderboard", Toast.LENGTH_LONG).show();

                                               } else {
                                                   JSONObject dataJson = new JSONObject();
                                                   try {
                                                       dataJson.put(TAG_NAME, name);
                                                       dataJson.put(TAG_TIME, difference);
                                                   } catch (JSONException e) {
                                                       Toast.makeText(getApplicationContext(), "Something Went Wrong", Toast.LENGTH_LONG).show();
                                                   }
                                                   Toast.makeText(getApplicationContext(), "You took " + difference + " Seconds to complete your run", Toast.LENGTH_LONG).show();
                                                   postData(url_create_product, dataJson, 1);
                                                   Intent myIntent = new Intent(Gps.this, Home.class);
                                                   startActivity(myIntent);


                                               }
                                           }
                                       }

                                   }

        );
    }
    public void postData(String url, final JSONObject json, final int option){
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest json_obj_req = new JsonObjectRequest(
                Request.Method.POST, url, json, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {


                switch (option){
                    case 1:checkResponseCreate_Product(response); break;

                }

            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
//                String alert_message;
//                alert_message = error.toString();
//                showAlertDialogue("Error", alert_message);
            }

        });
        requestQueue.add(json_obj_req);
    }

    public void checkResponseCreate_Product(JSONObject response)
    {
        Log.i("----Response", response+" ");
        try {
            if(response.getInt(TAG_SUCCESS)==1){

                finish();



                // dismiss the dialog once product uupdated


            }else{
                // product with pid not found
            }

        } catch (JSONException e) {
            e.printStackTrace();

        }

    }
    String updateTable(String sql)
    {
        try{
            System.out.println(sql);
            db.beginTransaction();
            db.execSQL(sql);
            db.setTransactionSuccessful();
            db.endTransaction();

        }catch (Exception e) { System.out.println(e.toString());
            return ("Error updating DB");
        }
        return ("DB updated");
    }
}

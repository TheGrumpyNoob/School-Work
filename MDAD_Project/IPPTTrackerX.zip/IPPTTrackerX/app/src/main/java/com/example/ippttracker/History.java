package com.example.ippttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class History extends AppCompatActivity {
    Button btnView, btnDelete;
    TextView tvStatus;
    SQLiteDatabase db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);
        tvStatus = (TextView)findViewById(R.id.tvStatus);
        btnView = (Button)findViewById(R.id.btnView);
        btnDelete = (Button)findViewById(R.id.btnDelete);


        db = openOrCreateDatabase("IPPT.db", MODE_PRIVATE, null);

        btnView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                tvStatus.setText("");
                // Select All data from table TelDirList
                String sql = "SELECT  * FROM  IPPT";
                String result = " Time\n";
                Cursor cursor = db.rawQuery(sql, null);
                if (cursor.moveToFirst()) {
                    do {
                        //get name and tel from sqlite db
                        String str = cursor.getString(cursor.getColumnIndex("Time")); //get time input from user

                        //add the name and tel to the result String
                        result = result + "\n" + str;
                    } while (cursor.moveToNext());
                }
                tvStatus.setText(result);
            }
        });
        btnView.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                tvStatus.setText("");
                // Select All data from table TelDirList
                String sql = "SELECT  * FROM  IPPT";
                String result = " Time\n";
                Cursor cursor = db.rawQuery(sql, null);
                if (cursor.moveToFirst()) {
                    do {
                        //get name and tel from sqlite db
                        String str = cursor.getString(cursor.getColumnIndex("Time")); //get time input from user

                        //add the name and tel to the result String
                        result = result + "\n" + str;
                    } while (cursor.moveToNext());
                }
                tvStatus.setText(result);
            }
        });
        btnDelete.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                String sql = "Drop Table IPPT";
                String result = updateTable(sql);
            }
        });

    }
    String updateTable(String sql)
    {
        try{
            System.out.println(sql);
            db.beginTransaction();
            db.execSQL(sql);
            db.setTransactionSuccessful();
            db.endTransaction();

        }catch (Exception e) { System.out.println(e.toString());
            return ("Error updating DB");
        }
        return ("DB updated");
    }
}
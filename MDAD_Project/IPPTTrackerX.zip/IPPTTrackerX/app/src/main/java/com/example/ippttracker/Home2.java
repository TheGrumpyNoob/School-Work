package com.example.ippttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class Home2 extends AppCompatActivity {
    public static String ipBaseAddress = "http://yippt.atspace.cc/App";
    Button btnViewProducts;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home2);

        ImageView imgview1 = (ImageView) findViewById(R.id.gpsImage);
        ImageView imgview2 = (ImageView) findViewById(R.id.historyImage);
        ImageView imgview3 = (ImageView) findViewById(R.id.ldrImage);
        ImageView imgview4 = (ImageView) findViewById(R.id.schImage);
        ImageView imgview5 = (ImageView) findViewById(R.id.calcImage);
        Button btnview = (Button) findViewById(R.id.logoutBtn);

        TextView t1;
        t1 = findViewById(R.id.txtUsername);

        SharedPreferences sp = getApplicationContext().getSharedPreferences("UserPref", Context.MODE_PRIVATE);
        String name = sp.getString("mUserName","");

        t1.setText(name);
        imgview1.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent myIntent1 = new Intent(Home2.this, Gps.class);
                                            startActivity(myIntent1);
                                        }
                                    }
        );
        imgview2.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent myIntent2 = new Intent(Home2.this, History.class);
                                            startActivity(myIntent2);
                                        }
                                    }
        );
        imgview3.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent myIntent3 = new Intent(Home2.this, Leaderboard.class);
                                            startActivity(myIntent3);
                                        }
                                    }
        );
        imgview4.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent myIntent4 = new Intent(Home2.this, Schedule.class);
                                            startActivity(myIntent4);
                                        }
                                    }
        );
        imgview5.setOnClickListener(new View.OnClickListener() {
                                        @Override
                                        public void onClick(View v) {
                                            Intent myIntent5 = new Intent(Home2.this, Calculator.class);
                                            startActivity(myIntent5);
                                        }
                                    }
        );
        btnview.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View v) {
                                           Intent myIntent6 = new Intent(Home2.this, MainActivity.class);

                                           startActivity(myIntent6);
                                       }
                                   }
        );
    }
}
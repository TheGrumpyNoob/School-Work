package com.example.ippttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    EditText mPassword,mUserName,username;
    Button btnSignIn;
    SQLiteDatabase db;
    SharedPreferences sp;
    String nameStr;
    SqlLiteHelper sqlh = new SqlLiteHelper();

    public static String ipBaseAddress = "http://yippt.atspace.cc/App";
    private static  String url_login = MainActivity.ipBaseAddress+"/LoginJ.php";
    private static final String TAG_SUCCESS = "success";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mUserName = (EditText) findViewById(R.id.username);
        mPassword = (EditText) findViewById(R.id.password);
        btnSignIn = (Button) findViewById(R.id.btnSignIn);
        Button btnregister = (Button) findViewById(R.id.register);

        btnregister.setOnClickListener(new View.OnClickListener() {
        public void onClick(View v) {
        Intent myIntent = new Intent(MainActivity.this, Register.class);
        startActivity(myIntent);
                                       }
                                   }
        );
        btnSignIn.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                String nameStr = mUserName.getText().toString();

                String uName = mUserName.getText().toString();
                String pw= mPassword.getText().toString();

                sp = getSharedPreferences("UserPref", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sp.edit();

                editor.putString("mUserName",nameStr);
                editor.commit();

                Toast.makeText(MainActivity.this, "Welcome", Toast.LENGTH_SHORT).show();

                if(pw.isEmpty())
                {
                    mPassword.setError(getString(R.string.error_field_required));

                }else

                if(uName.isEmpty())
                {
                    mUserName.setError(getString(R.string.error_field_required));

                }else
                {
                    JSONObject dataJson = new JSONObject();
                    try{
                        dataJson.put("username", uName);
                        dataJson.put("password", pw);


                    }catch(JSONException e){

                    }
                    postData(url_login,dataJson,1 );
                }

            }
        });
    }
            public void postData(String url, final JSONObject json, final int option){
                RequestQueue requestQueue = Volley.newRequestQueue(this);
                JsonObjectRequest json_obj_req = new JsonObjectRequest(
                        Request.Method.POST, url, json, new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {


                        switch (option){
                            case 1:checkResponseLogin(response); break;

                        }

                    }

                }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        error.printStackTrace();
//                String alert_message;
//                alert_message = error.toString();
//                showAlertDialogue("Error", alert_message);
                    }

                });
                requestQueue.add(json_obj_req);
            }
            public void checkResponseLogin(JSONObject response)
            {
                Log.i("----Response", response+" "+url_login);
                try {

                    if(response.getInt(TAG_SUCCESS)==1) {

                        finish();
                        Intent i = new Intent(this, Home2.class);

                        startActivity(i);
                        if (mUserName.getText().toString().equals("kam") &&
                                mPassword.getText().toString().equals("junwe12"))
                        {
                            Intent myIntent = new Intent(MainActivity.this, Home.class);
                            startActivity(myIntent);
                        }
                    }

                    else
                        {
                        Toast.makeText(this, "Wrong Password", Toast.LENGTH_SHORT).show();
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }

}

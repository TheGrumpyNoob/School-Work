package com.example.ippttracker;

import androidx.appcompat.app.AppCompatActivity;
import java.util.ArrayList;

import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.app.ProgressDialog;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class Register extends AppCompatActivity {

    Button reg;
    EditText etusername, etpassword, etname, etage, etheight, etweight;

    public static String ipBaseAddress = "http://yippt.atspace.cc/App";

    private static String url_create_product = Register.ipBaseAddress+"/insert.php";
        private static final String TAG_SUCCESS = "success";
    private static final String TAG_USERNAME = "username";
    private static final String TAG_PASSWORD = "password";
    private static final String TAG_NAME = "name";
    private static final String TAG_AGE = "age";
    private static final String TAG_HEIGHT = "weight";
    private static final String TAG_WEIGHT = "height";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        Log.i("Ip address CREATE ", url_create_product);


        reg = (Button) findViewById(R.id.reg);
        etusername = (EditText) findViewById(R.id.txtusername);
        etpassword = (EditText) findViewById(R.id.txtpassword);
        etname = (EditText) findViewById(R.id.txtname);
        etage = (EditText) findViewById(R.id.txtage);
        etheight = (EditText) findViewById(R.id.txtheight);
        etweight = (EditText) findViewById(R.id.txtweight);

        reg.setOnClickListener(new View.OnClickListener() {

            public void onClick(View arg0) {

                String username = etusername.getText().toString();
                String password = etpassword.getText().toString();
                String name = etname.getText().toString();
                String age = etage.getText().toString();
                String height = etheight.getText().toString();
                String weight = etweight.getText().toString();

                if (username.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please Fill in Username", Toast.LENGTH_LONG).show();

                } else if (password.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please Fill in Password", Toast.LENGTH_LONG).show();
                } else {
                    JSONObject dataJson = new JSONObject();
                    try {
                        dataJson.put(TAG_USERNAME, username);
                        dataJson.put(TAG_PASSWORD, password);
                        dataJson.put(TAG_NAME, name);
                        dataJson.put(TAG_AGE, age);
                        dataJson.put(TAG_HEIGHT, height);
                        dataJson.put(TAG_WEIGHT, weight);


                    } catch (JSONException e) {
                        Toast.makeText(getApplicationContext(), "Something Went Wrong", Toast.LENGTH_LONG).show();
                    }

                    postData(url_create_product, dataJson, 1);
                    Intent myIntent = new Intent(Register.this, MainActivity.class);
                    startActivity(myIntent);
                }
            }
        });
    }
    public void postData(String url, final JSONObject json, final int option){
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest json_obj_req = new JsonObjectRequest(
                Request.Method.POST, url, json, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {


                switch (option){
                    case 1:checkResponseCreate_Product(response); break;

                }

            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
//                String alert_message;
//                alert_message = error.toString();
//                showAlertDialogue("Error", alert_message);
            }

        });
        requestQueue.add(json_obj_req);
    }

    public void checkResponseCreate_Product(JSONObject response)
    {
        Log.i("----Response", response+" ");
        try {
            if(response.getInt(TAG_SUCCESS)==1){

                finish();



                // dismiss the dialog once product uupdated


            }else{
                // product with pid not found
            }

        } catch (JSONException e) {
            e.printStackTrace();

        }

    }
}


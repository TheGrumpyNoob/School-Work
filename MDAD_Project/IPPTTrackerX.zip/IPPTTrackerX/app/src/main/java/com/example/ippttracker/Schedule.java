package com.example.ippttracker;

import androidx.appcompat.app.AppCompatActivity;

import android.app.DatePickerDialog;
import android.app.ListActivity;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.icu.text.SimpleDateFormat;
import android.icu.util.TimeZone;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;


import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.w3c.dom.Text;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;


public class Schedule extends ListActivity {
    EditText eventname, showdate, showdate2;
    Button showevent, addevent;
    final Calendar myCalendar = Calendar.getInstance();
    ArrayList<HashMap<String, String>> eventsList;
    JSONArray time = null;

    public static String ipBaseAddress = "http://yippt.atspace.cc/App";

    private static String url_create_event = Schedule.ipBaseAddress + "/add_events.php";
    private static String url_view_event = Schedule.ipBaseAddress + "/select_events.php";
    private static final String TAG_SUCCESS = "success";
    private static final String TAG_EVENTS = "events";
    private static final String TAG_NAME = "name";
    private static final String TAG_DATE = "date";
    private static final String TAG_TIME = "time";
    private static final String TAG_EID = "eid";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_schedule);
        EditText eventname = (EditText) findViewById(R.id.eventname);
        EditText showdate = (EditText) findViewById(R.id.showdate);
        EditText showdate2 = (EditText) findViewById(R.id.showdate2);
        Button showevent = (Button) findViewById(R.id.showevent);
        Button addevent = (Button) findViewById(R.id.addevent);
        eventsList = new ArrayList<HashMap<String, String>>();

        ListView lv= getListView();

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int position, long id) {
                // getting values from selected ListItem

                // Starting new intent

                // sending pid to next activity

                // starting new activity and expecting some response back

            }
        });



        SimpleDateFormat simpdf = new SimpleDateFormat("yyyy-MM-dd ");
        SimpleDateFormat timesdf = new SimpleDateFormat("HH:mm");
        TimeZone timeZone1 = TimeZone.getTimeZone("Asia/Singapore");
        simpdf.setTimeZone(timeZone1);
        timesdf.setTimeZone(timeZone1);
        Calendar currentTime = Calendar.getInstance();
        String datetimeStamp = simpdf.format(currentTime.getTime());
        showdate.setText(datetimeStamp);
        String TimeStamp = timesdf.format(currentTime.getTime());
        showdate2.append(datetimeStamp);

        DatePickerDialog.OnDateSetListener date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                simpdf.setTimeZone(timeZone1);
                showdate.setText(simpdf.format(myCalendar.getTime()));
            }
        };
        showdate.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                DatePickerDialog dpd = new DatePickerDialog(Schedule.this, date, myCalendar.get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                        myCalendar.get(Calendar.DAY_OF_MONTH));
                dpd.getDatePicker().setMinDate(System.currentTimeMillis());
                dpd.show();
            }
        });
        showdate2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // TODO Auto-generated method stub
                Calendar mcurrentTime = Calendar.getInstance();
                int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                int minute = mcurrentTime.get(Calendar.MINUTE);
                TimePickerDialog mTimePicker;
                mTimePicker = new TimePickerDialog(Schedule.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                        showdate2.setText(selectedHour + ":" + selectedMinute);
                    }
                }, hour, minute, true);//Yes 24 hour time
                mTimePicker.setTitle("Select Time");
                mTimePicker.show();
            }
        });
        addevent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Category already assigned
                String name = eventname.getText().toString();
                String date = showdate.getText().toString() + showdate2.getText().toString();

                if (name.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please Fill in Event Name", Toast.LENGTH_LONG).show();

                } else if (date.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "Please Fill in Date", Toast.LENGTH_LONG).show();
                } else {
                    JSONObject dataJson = new JSONObject();
                    try {
                        dataJson.put(TAG_NAME, name);
                        dataJson.put(TAG_DATE, date);

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                    postData(url_create_event, dataJson, 1);


                    // creating new product in background thread
                    // new CreateNewProduct().execute();
                }
            }
        });
        showevent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                epostData(url_view_event,null );
            }
        });
    }
    public void postData (String url,final JSONObject json, final int option){
        Log.i("JSON", json.toString());
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest json_obj_req = new JsonObjectRequest(Request.Method.POST, url, json, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                switch (option) {
                    case 1:
                        checkResponseCreate_Product(response);
                        break;

                }

            }

        }
                , new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
//                String alert_message;
//                alert_message = error.toString();
//                showAlertDialogue("Error", alert_message);
            }

        });
        requestQueue.add(json_obj_req);
    }

    public void checkResponseCreate_Product (JSONObject response)
    {
        Log.i("----Response", response + " ");
        try {
            if (response.getInt(TAG_SUCCESS) == 1) {

                finish();


            } else {
                // product with pid not found
            }

        } catch (JSONException e) {
            e.printStackTrace();

        }
    }
    public void epostData(String url, final JSONObject json){
        RequestQueue requestQueue = Volley.newRequestQueue(this);

        JsonObjectRequest json_obj_req = new JsonObjectRequest(
                Request.Method.POST, url, json, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                echeckResponse(response, json);

//                String alert_message;
//                alert_message = response.toString();

//                showAlertDialogue("Response", alert_message);

            }

        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();

//                String alert_message;
//                alert_message = error.toString();

//                showAlertDialogue("Error", alert_message);

            }

        });

        requestQueue.add(json_obj_req);
    }
    private void echeckResponse(JSONObject response, JSONObject creds){
        try {
            if(response.getInt(TAG_SUCCESS)==1){

                // products found
                // Getting Array of Products
                time = response.getJSONArray(TAG_TIME);

                // looping through All Products
                for (int i = 0; i < time.length(); i++) {
                    JSONObject c = time.getJSONObject(i);

                    // Storing each json item in variable
                    String eid = c.getString(TAG_EID);
                    String name = c.getString(TAG_NAME);
                    String time = c.getString(TAG_DATE);

                    // creating new HashMap
                    HashMap<String, String> map = new HashMap<String, String>();

                    // adding each child node to HashMap key => value
                    map.put(TAG_EID, eid);
                    map.put(TAG_NAME, name);
                    map.put(TAG_DATE, time);

                    // adding HashList to ArrayList
                    eventsList.add(map);
                }

                /**
                 * Updating parsed JSON data into ListView
                 * */
                ListAdapter adapter = new SimpleAdapter(
                        Schedule.this, eventsList,
                        R.layout.list_time, new String[] { TAG_EID,
                        TAG_NAME, TAG_DATE},
                        new int[] { R.id.id, R.id.name, R.id.time });
                // updating listview
                setListAdapter(adapter);

            }
            else{

            }

        } catch (JSONException e) {
            e.printStackTrace();

        }

    }

}

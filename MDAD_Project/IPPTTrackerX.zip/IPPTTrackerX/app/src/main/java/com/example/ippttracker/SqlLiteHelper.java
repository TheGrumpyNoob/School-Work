package com.example.ippttracker;

import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

import java.util.ArrayList;

public class SqlLiteHelper {
    public String executeSQL(SQLiteDatabase db, String sql) {

        try {

            db.beginTransaction();
            db.execSQL(sql);
            db.setTransactionSuccessful();
            db.endTransaction();

        } catch (Exception e) {

            System.out.println(e.toString());
            return ("Error updating DB");
        }

        return ("DB updated");

    }
    public void readData(SQLiteDatabase db, String sqlStatement, ArrayList<String> name, ArrayList<String> listName, ArrayList<String> listID, ArrayList<String> listTel)
    {
        Cursor cursor = db.rawQuery(sqlStatement, null);
        // looping through all rows and adding to list
        if (cursor.moveToFirst()) {
            do {
                //Add each field of record to listName, listID,listTel
                listName.add(cursor.getString(cursor.getColumnIndex("Name")));
                listID.add(""+cursor.getInt(cursor.getColumnIndex("recId")));
                listTel.add(cursor.getString(cursor.getColumnIndex("Tel")));
                Log.i("Check it out",cursor.getString(cursor.getColumnIndex("Name"))+"" );
            } while (cursor.moveToNext());
        }
        // close db connection

        db.close();
    }

}